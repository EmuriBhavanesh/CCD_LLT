package com.classpathio.order.event;

public enum OrderStatus {
	ORDER_ACCEPTED,
	ORDER_FULLFILLED,
	ORDER_CANCELLED
}
